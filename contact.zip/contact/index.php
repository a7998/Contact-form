<form action="process.php" method="post">
<input type="email" name="mail">Email
<input type="text" name="name">Name
<input type="text" name="message">Subject
<input type="text" name="message2">Message
<Button name="send">Ok</Button>
</form>