<?php

if(isset($_POST['send'])) {

$user=$_POST['name'];
$email=$_POST['mail'];
$msg=$_POST['message'];
$msg2=$_POST['message2'];
if(empty($user)||empty($email)||empty($msg))
{
    echo"Error in one or more fields";
}

else {
$to="k2345w@gmail.com";

if(mail($to,$msg,$msg2,$email))
{
    echo "Succesful log in attempt";



}

}




}


?>